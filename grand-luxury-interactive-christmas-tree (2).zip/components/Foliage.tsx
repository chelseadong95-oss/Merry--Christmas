
import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TREE_CONFIG, COLORS } from '../constants';

interface FoliageProps {
  progress: number;
}

const Foliage: React.FC<FoliageProps> = ({ progress }) => {
  const pointsRef = useRef<THREE.Points>(null);

  const { chaosPositions, targetPositions, phases, colors } = useMemo(() => {
    const cPos = new Float32Array(TREE_CONFIG.FOLIAGE_COUNT * 3);
    const tPos = new Float32Array(TREE_CONFIG.FOLIAGE_COUNT * 3);
    const ph = new Float32Array(TREE_CONFIG.FOLIAGE_COUNT);
    const col = new Float32Array(TREE_CONFIG.FOLIAGE_COUNT * 3);

    const emerald = new THREE.Color(COLORS.EMERALD_DEEP);
    const gold = new THREE.Color(COLORS.GOLD_HIGH);

    for (let i = 0; i < TREE_CONFIG.FOLIAGE_COUNT; i++) {
      // Chaos: Random sphere
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = Math.random() * TREE_CONFIG.CHAOS_RADIUS;
      cPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      cPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      cPos[i * 3 + 2] = r * Math.cos(phi);

      // Target: Cone shape
      const h = Math.random() * TREE_CONFIG.HEIGHT;
      const radiusAtH = TREE_CONFIG.RADIUS * (1 - h / TREE_CONFIG.HEIGHT);
      const angle = Math.random() * Math.PI * 2;
      const jitter = (Math.random() - 0.5) * 0.5;
      
      tPos[i * 3] = (radiusAtH + jitter) * Math.cos(angle);
      tPos[i * 3 + 1] = h - (TREE_CONFIG.HEIGHT / 2); // Center tree vertically
      tPos[i * 3 + 2] = (radiusAtH + jitter) * Math.sin(angle);

      ph[i] = Math.random();

      // Color variation
      const mixFactor = Math.random();
      const finalCol = new THREE.Color().copy(emerald).lerp(gold, mixFactor * 0.15);
      col[i * 3] = finalCol.r;
      col[i * 3 + 1] = finalCol.g;
      col[i * 3 + 2] = finalCol.b;
    }

    return { chaosPositions: cPos, targetPositions: tPos, phases: ph, colors: col };
  }, []);

  useFrame((state) => {
    if (!pointsRef.current) return;
    const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;
    const time = state.clock.getElapsedTime();

    for (let i = 0; i < TREE_CONFIG.FOLIAGE_COUNT; i++) {
      const stagger = phases[i] * 0.3;
      const localProgress = Math.max(0, Math.min(1, (progress - stagger) / (1 - 0.3)));
      
      // Easing (Smoothstep)
      const t = localProgress * localProgress * (3 - 2 * localProgress);

      const i3 = i * 3;
      // Position Interpolation
      const px = chaosPositions[i3] + (targetPositions[i3] - chaosPositions[i3]) * t;
      const py = chaosPositions[i3 + 1] + (targetPositions[i3 + 1] - chaosPositions[i3 + 1]) * t;
      const pz = chaosPositions[i3 + 2] + (targetPositions[i3 + 2] - chaosPositions[i3 + 2]) * t;

      // Add a bit of swaying logic when formed
      const sway = Math.sin(time + phases[i] * 10) * 0.02 * t;
      positions[i3] = px + sway;
      positions[i3 + 1] = py;
      positions[i3 + 2] = pz + sway;
    }
    pointsRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={TREE_CONFIG.FOLIAGE_COUNT}
          array={new Float32Array(TREE_CONFIG.FOLIAGE_COUNT * 3)}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={TREE_CONFIG.FOLIAGE_COUNT}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.06}
        vertexColors
        transparent
        opacity={0.8}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
};

export default Foliage;
