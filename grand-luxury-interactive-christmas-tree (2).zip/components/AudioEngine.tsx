
import React, { useEffect, useRef } from 'react';

interface AudioEngineProps {
  isMuted: boolean;
  isPlaying: boolean;
}

const AudioEngine: React.FC<AudioEngineProps> = ({ isMuted, isPlaying }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Cinematic, orchestral Christmas track
    const audio = new Audio('https://cdn.pixabay.com/audio/2021/11/24/audio_924a49622d.mp3');
    audio.loop = true;
    audio.volume = 0.4;
    audioRef.current = audio;

    return () => {
      audio.pause();
      audio.src = "";
    };
  }, []);

  useEffect(() => {
    if (!audioRef.current) return;

    if (isPlaying && !isMuted) {
      audioRef.current.play().catch(e => console.log("Audio play blocked", e));
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying, isMuted]);

  useEffect(() => {
    if (!audioRef.current) return;
    audioRef.current.muted = isMuted;
  }, [isMuted]);

  return null;
};

export default AudioEngine;
