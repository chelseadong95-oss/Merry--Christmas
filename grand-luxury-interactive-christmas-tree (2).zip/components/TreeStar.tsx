
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { COLORS, TREE_CONFIG } from '../constants';

interface TreeStarProps {
  progress: number;
}

const TreeStar: React.FC<TreeStarProps> = ({ progress }) => {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!meshRef.current) return;
    const time = state.clock.getElapsedTime();
    
    // Position at top
    const targetY = TREE_CONFIG.HEIGHT / 2 + 0.5;
    const chaosY = 0;
    
    meshRef.current.position.y = chaosY + (targetY - chaosY) * progress;
    meshRef.current.rotation.y = time * 2;
    meshRef.current.scale.setScalar(progress * 1.5);
  });

  return (
    <mesh ref={meshRef}>
      <octahedronGeometry args={[0.5, 0]} />
      <meshStandardMaterial 
        color={COLORS.GOLD_HIGH} 
        emissive={COLORS.GOLD_HIGH} 
        emissiveIntensity={2} 
        metalness={1} 
        roughness={0} 
      />
    </mesh>
  );
};

export default TreeStar;
