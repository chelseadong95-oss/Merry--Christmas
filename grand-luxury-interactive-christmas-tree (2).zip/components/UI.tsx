
import React from 'react';
import { COLORS } from '../constants';

interface UIProps {
  isFormed: boolean;
  toggleState: () => void;
  isMuted: boolean;
  toggleMute: () => void;
}

const UI: React.FC<UIProps> = ({ isFormed, toggleState, isMuted, toggleMute }) => {
  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12">
      {/* Header */}
      <header className="flex justify-between items-start pointer-events-auto w-full">
        <div className="text-white">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight luxury-font">
            GRAND <span className="text-[#D4AF37]">LUXURY</span>
          </h1>
          <p className="text-sm md:text-lg opacity-60 tracking-[0.2em] font-light mt-2 uppercase">
            Christmas Experience MMXXIV
          </p>
        </div>

        <div className="flex gap-8 items-start">
          <div className="hidden md:block text-right">
            <p className="text-xs text-[#D4AF37] uppercase tracking-widest font-bold">Location</p>
            <p className="text-white opacity-80 luxury-font text-xl">The Emerald Ballroom</p>
          </div>

          {/* Sound Toggle */}
          <button 
            onClick={toggleMute}
            className="group flex flex-col items-center justify-center p-2 rounded-full border border-[#D4AF37]/30 hover:border-[#D4AF37] transition-all duration-300 bg-black/20 backdrop-blur-sm"
            aria-label={isMuted ? "Unmute" : "Mute"}
          >
            <div className="w-8 h-8 flex items-center justify-center text-[#D4AF37]">
              {isMuted ? (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75 19.5 12m0 0 2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6 4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.5a.75.75 0 0 1-.75-.75V9.75a.75.75 0 0 1 .75-.75h2.25Z" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 0 1 0 12.728M16.463 8.288a5.25 5.25 0 0 1 0 7.424M6.75 8.25l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.5a.75.75 0 0 1-.75-.75V9.75a.75.75 0 0 1 .75-.75h2.25Z" />
                </svg>
              )}
            </div>
            <span className="text-[8px] text-[#D4AF37] uppercase font-bold tracking-widest mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {isMuted ? "OFF" : "ON"}
            </span>
          </button>
        </div>
      </header>

      {/* Center Message */}
      <div className="flex-1 flex items-center justify-center">
        {!isFormed && (
          <div className="text-center animate-pulse">
            <p className="text-white opacity-40 uppercase tracking-[0.5em] text-sm">Waiting for the magic</p>
          </div>
        )}
      </div>

      {/* Footer Controls */}
      <footer className="flex flex-col md:flex-row justify-between items-end gap-8">
        <div className="max-w-md pointer-events-auto bg-black/40 backdrop-blur-md p-6 border-l-4 border-[#D4AF37]">
          <h2 className="text-[#D4AF37] text-xl mb-2 font-bold uppercase tracking-wider">The Concept</h2>
          <p className="text-white/80 text-sm leading-relaxed">
            Witness the fusion of chaos and order. Thousands of golden particles and emerald needles assemble 
            into a grand structure of festive opulence, reflecting a world of unparalleled luxury.
          </p>
        </div>

        <div className="pointer-events-auto flex flex-col items-center gap-4">
          <button
            onClick={toggleState}
            className={`
              px-10 py-4 text-lg font-bold uppercase tracking-[0.2em] transition-all duration-700
              ${isFormed 
                ? 'bg-transparent border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10' 
                : 'bg-[#D4AF37] text-black hover:bg-white hover:shadow-[0_0_30px_#D4AF37]'
              }
            `}
          >
            {isFormed ? 'Scatter Fragments' : 'Assemble Grandeur'}
          </button>
          <p className="text-white/40 text-[10px] uppercase tracking-widest">
            {isFormed ? 'State: Formed' : 'State: Chaos'}
          </p>
        </div>
      </footer>
    </div>
  );
};

export default UI;
