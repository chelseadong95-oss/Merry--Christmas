
import React, { useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, Float, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom, Noise, Vignette } from '@react-three/postprocessing';
import Foliage from './Foliage';
import Ornaments from './Ornaments';
import TreeStar from './TreeStar';
import { COLORS, TREE_CONFIG } from '../constants';

interface SceneProps {
  isFormed: boolean;
}

const Scene: React.FC<SceneProps> = ({ isFormed }) => {
  const [progress, setProgress] = useState(0);

  // Transition logic
  useEffect(() => {
    let animationFrame: number;
    const target = isFormed ? 1 : 0;
    const speed = 0.008;

    const animate = () => {
      setProgress((prev) => {
        const diff = target - prev;
        if (Math.abs(diff) < 0.001) return target;
        return prev + diff * speed;
      });
      animationFrame = requestAnimationFrame(animate);
    };

    animate();
    return () => cancelAnimationFrame(animationFrame);
  }, [isFormed]);

  return (
    <Canvas shadows gl={{ antialias: false, stencil: false, depth: true }}>
      <color attach="background" args={[COLORS.BACKGROUND]} />
      <PerspectiveCamera makeDefault position={[0, 5, 20]} fov={45} />
      <OrbitControls 
        enablePan={false} 
        minDistance={5} 
        maxDistance={35} 
        autoRotate={isFormed && progress > 0.9} 
        autoRotateSpeed={0.5}
      />

      <ambientLight intensity={0.2} />
      <spotLight position={[10, 20, 10]} angle={0.15} penumbra={1} intensity={2} color={COLORS.GOLD_SOFT} castShadow />
      <pointLight position={[-10, -5, -10]} intensity={1} color={COLORS.EMERALD_DEEP} />
      
      <Environment preset="lobby" />

      <group position={[0, 0, 0]}>
        <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.2}>
          <Foliage progress={progress} />
          <Ornaments progress={progress} />
          <TreeStar progress={progress} />
        </Float>
        
        {/* Magic Dust */}
        {progress > 0.5 && (
          <Sparkles 
            count={200} 
            scale={[TREE_CONFIG.RADIUS * 2, TREE_CONFIG.HEIGHT, TREE_CONFIG.RADIUS * 2]} 
            size={4} 
            speed={0.4} 
            color={COLORS.GOLD_HIGH} 
          />
        )}
      </group>

      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.8} 
          mipmapBlur 
          intensity={1.2} 
          radius={0.4} 
        />
        <Noise opacity={0.05} />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
      </EffectComposer>
    </Canvas>
  );
};

export default Scene;
