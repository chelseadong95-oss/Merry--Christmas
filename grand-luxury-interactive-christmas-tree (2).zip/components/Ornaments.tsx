
import React, { useMemo, useRef, useState } from 'react';
import { useFrame, ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';
import { TREE_CONFIG, COLORS } from '../constants';
import { OrnamentData } from '../types';

interface OrnamentsProps {
  progress: number;
}

const Ornaments: React.FC<OrnamentsProps> = ({ progress }) => {
  const ballRef = useRef<THREE.InstancedMesh>(null);
  const giftRef = useRef<THREE.InstancedMesh>(null);
  const lightRef = useRef<THREE.InstancedMesh>(null);

  // Track hover state for individual instances
  const [hovered, setHovered] = useState<{ type: 'BALL' | 'GIFT' | 'LIGHT'; index: number } | null>(null);

  const ornamentData = useMemo(() => {
    const data: OrnamentData[] = [];
    const types: ('BALL' | 'GIFT' | 'LIGHT')[] = ['BALL', 'GIFT', 'LIGHT'];
    const palette = [COLORS.GOLD_HIGH, COLORS.RUBY_RED, COLORS.SILVER, COLORS.GOLD_SOFT];

    for (let i = 0; i < TREE_CONFIG.ORNAMENT_COUNT; i++) {
      const type = types[i % 3];
      
      // Chaos Position
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = Math.random() * TREE_CONFIG.CHAOS_RADIUS;
      const chaosPos = new THREE.Vector3(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta),
        r * Math.cos(phi)
      );

      // Target Position (Conical but slightly outside for visibility)
      const h = Math.random() * TREE_CONFIG.HEIGHT;
      const radiusAtH = TREE_CONFIG.RADIUS * (1 - h / TREE_CONFIG.HEIGHT);
      const angle = Math.random() * Math.PI * 2;
      
      const targetPos = new THREE.Vector3(
        radiusAtH * Math.cos(angle),
        h - (TREE_CONFIG.HEIGHT / 2),
        radiusAtH * Math.sin(angle)
      );

      data.push({
        id: i,
        chaosPosition: chaosPos,
        targetPosition: targetPos,
        type,
        color: palette[Math.floor(Math.random() * palette.length)],
        size: type === 'GIFT' ? 0.3 : (type === 'BALL' ? 0.2 : 0.08),
        phase: Math.random(),
        weight: type === 'GIFT' ? 1.5 : (type === 'BALL' ? 1.0 : 0.2)
      });
    }
    return data;
  }, []);

  const ballData = useMemo(() => ornamentData.filter(d => d.type === 'BALL'), [ornamentData]);
  const giftData = useMemo(() => ornamentData.filter(d => d.type === 'GIFT'), [ornamentData]);
  const lightData = useMemo(() => ornamentData.filter(d => d.type === 'LIGHT'), [ornamentData]);

  const updateInstance = (mesh: THREE.InstancedMesh, dataItems: OrnamentData[], type: 'BALL' | 'GIFT' | 'LIGHT', time: number) => {
    const matrix = new THREE.Matrix4();
    const pos = new THREE.Vector3();
    const rot = new THREE.Quaternion();
    const scale = new THREE.Vector3();
    const color = new THREE.Color();

    dataItems.forEach((item, i) => {
      // Per-item staggered progress
      const stagger = item.phase * 0.4;
      const localProgress = Math.max(0, Math.min(1, (progress - stagger) / (1 - 0.4)));
      const t = localProgress * localProgress * (3 - 2 * localProgress); // Smoothstep

      pos.lerpVectors(item.chaosPosition, item.targetPosition, t);
      
      // Check if this specific instance is hovered
      const isHovered = hovered?.type === type && hovered?.index === i;
      
      // Spinning animation
      const spinSpeed = (1 / item.weight) * (isHovered ? 4 : 1);
      rot.setFromEuler(new THREE.Euler(time * spinSpeed + item.phase, time * spinSpeed, item.phase));
      
      // Hover and Hover effect when formed
      if (progress > 0.9) {
        const floatAmp = isHovered ? 0.15 : 0.05;
        pos.y += Math.sin(time * 2 + item.phase * 10) * floatAmp;
      }

      // Reactive scaling
      const hoverScale = isHovered ? 1.5 : 1.0;
      scale.setScalar(item.size * hoverScale);
      
      matrix.compose(pos, rot, scale);
      mesh.setMatrixAt(i, matrix);
      
      // Reactive color shift
      color.set(item.color);
      if (isHovered) {
        color.lerp(new THREE.Color('#ffffff'), 0.5);
      }
      mesh.setColorAt(i, color);
    });
    
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  };

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (ballRef.current) updateInstance(ballRef.current, ballData, 'BALL', time);
    if (giftRef.current) updateInstance(giftRef.current, giftData, 'GIFT', time);
    if (lightRef.current) updateInstance(lightRef.current, lightData, 'LIGHT', time);
  });

  const handlePointerOver = (e: ThreeEvent<PointerEvent>, type: 'BALL' | 'GIFT' | 'LIGHT') => {
    e.stopPropagation();
    if (e.instanceId !== undefined) {
      setHovered({ type, index: e.instanceId });
    }
  };

  const handlePointerOut = () => {
    setHovered(null);
  };

  return (
    <group onPointerOut={handlePointerOut}>
      {/* Balls */}
      <instancedMesh 
        ref={ballRef} 
        args={[undefined, undefined, ballData.length]}
        onPointerMove={(e) => handlePointerOver(e, 'BALL')}
      >
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial metalness={0.9} roughness={0.1} />
      </instancedMesh>

      {/* Gifts */}
      <instancedMesh 
        ref={giftRef} 
        args={[undefined, undefined, giftData.length]}
        onPointerMove={(e) => handlePointerOver(e, 'GIFT')}
      >
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial metalness={0.4} roughness={0.6} />
      </instancedMesh>

      {/* Lights (Glowy bits) */}
      <instancedMesh 
        ref={lightRef} 
        args={[undefined, undefined, lightData.length]}
        onPointerMove={(e) => handlePointerOver(e, 'LIGHT')}
      >
        <sphereGeometry args={[1, 16, 16]} />
        <meshStandardMaterial emissive={COLORS.GOLD_HIGH} emissiveIntensity={5} />
      </instancedMesh>
    </group>
  );
};

export default Ornaments;
