
import { Vector3 } from 'three';

export enum TreeState {
  CHAOS = 'CHAOS',
  FORMED = 'FORMED'
}

export interface OrnamentData {
  id: number;
  chaosPosition: Vector3;
  targetPosition: Vector3;
  type: 'BALL' | 'GIFT' | 'LIGHT';
  color: string;
  size: number;
  phase: number;
  weight: number; // For push physics/inertia simulation
}

export interface FoliageData {
  chaosPositions: Float32Array;
  targetPositions: Float32Array;
  phases: Float32Array;
  colors: Float32Array;
}
