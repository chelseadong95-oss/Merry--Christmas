
import React, { useState } from 'react';
import Scene from './components/Scene';
import UI from './components/UI';
import AudioEngine from './components/AudioEngine';
import { TreeState } from './types';

const App: React.FC = () => {
  const [treeState, setTreeState] = useState<TreeState>(TreeState.CHAOS);
  const [isMuted, setIsMuted] = useState(true);
  const [hasInteracted, setHasInteracted] = useState(false);

  const toggleTreeState = () => {
    if (!hasInteracted) {
      setHasInteracted(true);
      setIsMuted(false); // Unmute on first interaction for better UX
    }
    setTreeState(prev => prev === TreeState.CHAOS ? TreeState.FORMED : TreeState.CHAOS);
  };

  const toggleMute = () => {
    if (!hasInteracted) setHasInteracted(true);
    setIsMuted(!isMuted);
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#010d0a]">
      {/* Audio Layer */}
      <AudioEngine isMuted={isMuted} isPlaying={hasInteracted} />

      {/* 3D Scene Background */}
      <div className="absolute inset-0">
        <Scene isFormed={treeState === TreeState.FORMED} />
      </div>

      {/* Decorative Overlays (Luxury Feel) */}
      <div className="absolute inset-0 pointer-events-none border-[20px] border-[#D4AF37]/10 mix-blend-overlay"></div>
      
      {/* UI Controls */}
      <UI 
        isFormed={treeState === TreeState.FORMED} 
        toggleState={toggleTreeState}
        isMuted={isMuted}
        toggleMute={toggleMute}
      />

      {/* Background Ambience Text (Very subtle) */}
      <div className="absolute bottom-4 left-4 pointer-events-none opacity-5 text-white text-[12vw] font-black luxury-font leading-none select-none">
        MERRY XMAS
      </div>
    </div>
  );
};

export default App;
